create function gettaskdefition(defitionid integer, taskid integer) returns jsonb
LANGUAGE SQL
AS $$
SELECT task
FROM (
       SELECT jsonb_array_elements_text(content -> 'nodes') :: JSONB AS task
       FROM process_definition
       WHERE id = defitionId) t
WHERE task ->> 'id' = taskId::text;
$$;
